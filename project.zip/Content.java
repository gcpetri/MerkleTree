package MerkleTree;

public abstract class Content {
	
	protected String from;
	protected String to;
	protected double amount;
	
	public Content() {
		
	}
	
}
