Final YouTube Video Link:

https://www.youtube.com/watch?v=Un3aCkIsq_M&feature=youtu.be


Github:

https://github.com/gcpetri/MerkleTree314